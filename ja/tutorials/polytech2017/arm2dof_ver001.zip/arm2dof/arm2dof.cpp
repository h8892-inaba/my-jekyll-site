﻿// -*- C++ -*-
#include <iostream>
#define _USE_MATH_DEFINES
#include <math.h>

struct LinkLength
{
  double l0;
  double l1;
};
struct Position
{
  double x;
  double y;
};
struct JointAngle
{
  double th0;
  double th1;
};

JointAngle invkinem(LinkLength link, Position pos)
{
  // ここに2自由度アームの逆運動学計算を追記
  // link, pos -> jointangle

  JointAngle j = {0.0, 0.0};
  return j;
}

int main(void)
{
  LinkLength l = {1.0, 1.0};
  Position pos[] = {
    {-1.0, 1.0},
    {-0.5, 1.0},
    { 0.0, 1.0},
    { 0.5, 1.0},
    { 1.0, 1.0},
  };

  for (int i(0); i < 5; ++i)
    {
      JointAngle j = invkinem(l, pos[i]);
      std::cout << "pos (x, y): " << pos[i].x << ", " << pos[i].y << "\t ==> ";
      std::cout << "angle (th0, th1): " << j.th0 << ", " << j.th1 << std::endl;
    }
  return 0;
}
