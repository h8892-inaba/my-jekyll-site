#!/usr/bin/python
# -*- coding: utf-8 -*- 
import sys
import time


import rtctree.tree



def main():
    tree = rtctree.tree.RTCTree(servers="localhost:2809")
    mgr = tree.get_node(['/', 'localhost:2809','manager.mgr'])
    mgr.shutdown()
    

if __name__ == "__main__":
    main()